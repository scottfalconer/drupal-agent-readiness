#!/usr/bin/env python3
"""Build full Drupal CMS config coverage manifest.

This inventories config shipped by Drupal CMS recipes plus the Drupal CMS
installer profile, then maps each config object to a catalog intent or a
deliberate no-seed/aggregate classification.
"""

from __future__ import annotations

import csv
from fnmatch import fnmatch
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
DRUPAL_CMS_ROOT = REPO_ROOT / "drupal_cms-3591393"
CATALOG_PATH = Path(__file__).with_name("drupal-cms-recipe-intents.csv")
COVERAGE_PATH = Path(__file__).with_name("drupal-cms-config-coverage.csv")


ENTITY_PREFIXES = (
    "ai_agents.ai_agent.",
    "ai_assistant_api.ai_assistant.",
    "block.block.",
    "block_content.type.",
    "canvas.asset_library.",
    "canvas.brand_kit.",
    "canvas.component.",
    "core.base_field_override.",
    "core.date_format.",
    "core.entity_form_display.",
    "core.entity_form_mode.",
    "core.entity_view_display.",
    "core.entity_view_mode.",
    "dashboard.dashboard.",
    "eca.eca.",
    "editor.editor.",
    "field.field.",
    "field.storage.",
    "filter.format.",
    "google_tag.container.",
    "image.style.",
    "klaro.klaro_app.",
    "linkit.linkit_profile.",
    "media.type.",
    "metatag.metatag_defaults.",
    "node.type.",
    "pathauto.pattern.",
    "responsive_image.styles.",
    "search_api.index.",
    "search_api.server.",
    "shortcut.set.",
    "system.action.",
    "system.menu.",
    "taxonomy.vocabulary.",
    "user.role.",
    "views.view.",
    "webform.webform.",
    "workflows.workflow.",
)


DEFAULT_INTENT_BY_OWNER = {
    "drupal_cms_accessibility_tools": "accessibility_editoria11y_results_view",
    "drupal_cms_admin_ui": "admin_ui_dashboard_navigation",
    "drupal_cms_ai": "ai_site_builder_assistant",
    "drupal_cms_anti_spam": "anti_spam_altcha_honeypot_forms",
    "drupal_cms_authentication": "authentication_login_registration_redirects",
    "drupal_cms_content_type_base": "content_page_content_model",
    "drupal_cms_forms": "forms_contact_form",
    "drupal_cms_google_analytics": "google_analytics_privacy_aware_tagging",
    "drupal_cms_media": "media_responsive_image_system",
    "drupal_cms_privacy_basic": "privacy_consent_management",
    "drupal_cms_search": "search_content_index_and_results",
    "drupal_cms_seo_basic": "seo_basic_paths_and_redirects",
    "drupal_cms_seo_tools": "seo_metadata_fallbacks_social_images",
    "drupal_cms_site_template_base": "site_template_base_blank_foundation",
    "drupal_cms_starter": "starter_aggregate_basics",
    "drupal_cms_installer": "installer_administrator_role",
}


RULES: list[tuple[str, str, str, str, str]] = []


def rule(owner: str, pattern: str, intent_id: str, status: str, note: str) -> None:
    RULES.append((owner, pattern, intent_id, status, note))


# Accessibility Tools.
rule("*", "views.view.a11y_tools_editoria11y_results", "accessibility_editoria11y_results_view", "intent_covered", "Accessibility results view.")
rule("*", "editoria11y.settings", "accessibility_ignore_map_tiles_editoria11y", "not_attachable_v0_intent_covered", "Simple config action with direct inline rationale.")

# Admin UI.
for pattern in ("dashboard.dashboard.welcome", "system.menu.top-tasks", "navigation.block_layout", "core.menu.static_menu_link_overrides"):
    rule("*", pattern, "admin_ui_dashboard_navigation", "intent_covered", "Admin UI navigation/dashboard setup.")
rule("*", "package_manager.settings", "admin_ui_package_manager_trusted_plugins", "not_attachable_v0_intent_covered", "Simple config technical workaround.")
for pattern in ("user.role.authenticated", "user.role.content_editor", "?user.role.content_editor"):
    rule("drupal_cms_admin_ui", pattern, "admin_ui_dashboard_permissions", "intent_covered", "Dashboard access permissions.")
for pattern in ("announcements_feed.settings", "automatic_updates.settings", "drupical.settings", "gin_login.settings", "project_browser.admin_settings", "system.theme", "tagify.settings", "update.settings"):
    rule("drupal_cms_admin_ui", pattern, "admin_ui_dashboard_navigation", "supporting_config_intent_covered", "Supporting Admin UI configuration.")

# AI Assistant.
for pattern in ("ai_*", "ai.settings", "ai_agents.settings", "ai_provider_*.settings", "block.block.ai_chatbot", "klaro.klaro_app.deepchat", "klaro.klaro_app.ai_alt_text_generation", "user.role.content_editor"):
    rule("drupal_cms_ai", pattern, "ai_site_builder_assistant", "intent_covered", "AI assistant/provider/privacy setup.")

# Anti-spam.
for pattern in ("altcha.settings", "captcha.settings", "honeypot.settings"):
    rule("*", pattern, "anti_spam_altcha_honeypot_forms", "intent_covered", "Anti-spam settings.")
rule("drupal_cms_anti_spam", "user.role.authenticated", "anti_spam_altcha_honeypot_forms", "intent_covered", "Anti-spam bypass permission.")

# Authentication.
for pattern in ("field.field.user.user.user_picture", "core.entity_view_display.user.user.*"):
    rule("drupal_cms_authentication", pattern, "authentication_user_picture_avatar", "intent_covered", "User picture/avatar setup.")
for pattern in ("system.site", "user.settings", "eca.eca.auth_redirects"):
    rule("drupal_cms_authentication", pattern, "authentication_login_registration_redirects", "intent_covered", "Login, registration, and logout behavior.")

# Content Basics.
for pattern in ("field.field.node.page.field_featured_image", "field.storage.node.field_featured_image"):
    rule("*", pattern, "content_page_featured_image_media", "intent_covered", "Featured image media field.")
for pattern in ("filter.format.content_format", "filter.format.canvas_html_*", "editor.editor.content_format", "editor.editor.canvas_html_*", "linkit.linkit_profile.default"):
    rule("*", pattern, "content_rich_text_format", "intent_covered", "Shared content text format/editor setup.")
for pattern in ("workflows.workflow.basic_editorial", "eca.eca.auto_enable_moderation", "eca.eca.auto_configure_scheduler", "views.view.moderated_content", "views.view.publishing_content", "scheduler.settings", "user.role.content_editor"):
    rule("*", pattern, "content_editorial_workflow_scheduling", "intent_covered", "Editorial workflow and scheduling.")
for pattern in ("eca.eca.content_duplicate", "eca.eca.content_template_disable_preview", "eca.eca.unpublished_404"):
    rule("*", pattern, "content_editor_support_automation", "intent_covered", "Content support automation.")
for pattern in ("node.type.page", "field.storage.node.field_content", "field.storage.node.field_description", "field.storage.node.field_tags", "field.field.node.page.field_content", "field.field.node.page.field_description", "field.field.node.page.field_tags", "core.entity_form_display.node.page.*", "core.entity_view_display.node.page.*", "core.entity_view_mode.node.card", "pathauto.pattern.page_content", "taxonomy.vocabulary.tags", "views.view.recent_content", "views.view.recent_pages", "views.view.taxonomy_term", "autosave_form.settings", "node.settings", "tagify.settings", "trash.settings", "views.view.scheduler_scheduled_media", "views.view.scheduler_scheduled_taxonomy_term"):
    rule("*", pattern, "content_page_content_model", "intent_covered", "Baseline editorial content model and supporting admin views.")
for pattern in ("user.role.anonymous", "user.role.authenticated"):
    rule("drupal_cms_content_type_base", pattern, "content_page_content_model", "intent_covered", "Baseline content access permissions.")

# Forms.
for pattern in ("webform.webform.contact_form", "webform.settings"):
    rule("*", pattern, "forms_contact_form", "intent_covered", "Contact form and Webform defaults.")

# Google Analytics.
for pattern in ("google_tag.settings", "google_tag.container.drupal", "klaro.klaro_app.ga", "klaro.klaro_app.gtm"):
    rule("*", pattern, "google_analytics_privacy_aware_tagging", "intent_covered", "Google Tag plus Klaro integration.")
for pattern in ("klaro.settings",):
    rule("drupal_cms_google_analytics", pattern, "google_analytics_privacy_aware_tagging", "intent_covered", "Google Tag plus Klaro integration.")

# Media. Order matters: SVG and remote video before broad media/image rules.
for pattern in ("media.type.svg_image", "field.storage.media.field_media_svg_image", "field.field.media.svg_image.*", "core.entity_form_display.media.svg_image.*", "core.entity_view_display.media.svg_image.*"):
    rule("*", pattern, "media_svg_as_media", "intent_covered", "SVG as first-class media.")
for pattern in ("eca.eca.remote_video_consent", "klaro.klaro_app.youtube", "klaro.klaro_app.vimeo"):
    rule("*", pattern, "media_remote_video_consent", "intent_covered", "Remote video consent automation.")
for pattern in ("media_file_delete.settings", "eca.eca.grant_media_type_permissions", "views.view.files", "file.settings", "user.role.authenticated", "user.role.content_editor"):
    rule("drupal_cms_media", pattern, "media_management_file_lifecycle", "intent_covered", "Media management and file lifecycle behavior.")
for pattern in ("core.entity_view_mode.media.*", "core.entity_view_display.media.*", "core.entity_form_display.media.*.*", "image.style.*", "responsive_image.styles.*", "eca.eca.define_breakpoints"):
    rule("*", pattern, "media_responsive_image_system", "intent_covered", "Responsive media/image system.")

# Privacy.
rule("*", "klaro.klaro_app.*", "privacy_consent_management", "intent_covered", "Klaro app/service consent configuration.")
for pattern in ("klaro.settings", "eca.eca.privacy_setting_link", "menu_link_attributes.config", "user.role.anonymous", "user.role.authenticated", "klaro.klaro_app.cms"):
    rule("drupal_cms_privacy_basic", pattern, "privacy_consent_management", "intent_covered", "Consent and privacy settings.")

# Search.
for pattern in ("eca.eca.search_exclude",):
    rule("*", pattern, "search_content_exclusion_control", "intent_covered", "Per-content search exclusion.")
rule("drupal_cms_search", "node.type.*", "search_content_exclusion_control", "intent_covered", "Per-content search exclusion.")
for pattern in ("search_api.index.content", "search_api.server.database", "views.view.search", "core.entity_view_mode.node.search_index", "core.entity_view_display.node.*.default"):
    rule("*", pattern, "search_content_index_and_results", "intent_covered", "Search index and results.")

# SEO.
for pattern in ("pathauto.pattern.menu_path", "views.view.redirect", "redirect_404.settings", "easy_breadcrumb.settings"):
    rule("*", pattern, "seo_basic_paths_and_redirects", "intent_covered", "Basic SEO paths, breadcrumbs, and redirects.")
for pattern in ("system.performance", "user.role.content_editor"):
    rule("drupal_cms_seo_basic", pattern, "seo_basic_paths_and_redirects", "intent_covered", "Basic SEO paths, breadcrumbs, redirects, and performance defaults.")
for pattern in ("field.storage.node.field_seo_*", "eca.eca.setup_seo_fields"):
    rule("*", pattern, "seo_editor_fields", "intent_covered", "Editor-owned SEO fields.")
for pattern in ("eca.eca.node_sitemap_settings",):
    rule("*", pattern, "seo_xml_sitemap_defaults", "intent_covered", "XML sitemap setup.")
for pattern in ("metatag.metatag_defaults.*", "image.style.social_media_*"):
    rule("*", pattern, "seo_metadata_fallbacks_social_images", "intent_covered", "Metatag fallbacks and social image styles.")
rule("drupal_cms_seo_tools", "system.performance", "seo_metadata_fallbacks_social_images", "supporting_config_intent_covered", "SEO Tools performance defaults.")

# Site Template Base.
for pattern in ("klaro.texts", "system.performance", "system.site", "system.theme", "canvas.component.*", "?canvas.component.*"):
    rule("drupal_cms_site_template_base", pattern, "site_template_base_blank_foundation", "intent_covered", "Blank site-template foundation actions.")

# Installer profile.
rule("drupal_cms_installer", "user.role.administrator", "installer_administrator_role", "intent_covered", "Installer administrator role.")


def clean_config_name(name: str) -> str:
    return name[1:] if name.startswith("?") else name


def infer_v0_attachable(config_name: str) -> str:
    clean = clean_config_name(config_name)
    if any(ch in clean for ch in "*%"):
        return "yes-wildcard" if clean.startswith(ENTITY_PREFIXES) else "no"
    if clean.startswith(ENTITY_PREFIXES):
        return "yes"
    return "no"


def load_catalog() -> dict[str, str]:
    with CATALOG_PATH.open(newline="") as handle:
        return {
            row["intent_id"]: row["draft_intent_value"]
            for row in csv.DictReader(handle)
        }


def action_targets(recipe_yml: Path) -> list[str]:
    targets: list[str] = []
    in_actions = False
    for line in recipe_yml.read_text().splitlines():
        if line.startswith("  actions:"):
            in_actions = True
            continue
        if not in_actions:
            continue
        if line and not line.startswith("    "):
            break
        if line.startswith("    ") and line.strip() and not line.startswith("      "):
            stripped = line.strip()
            if not stripped.startswith("#"):
                targets.append(stripped.rstrip(":"))
    return targets


def config_name_from_file(path: Path) -> str:
    return path.name.removesuffix(".yml")


def match_intent(owner: str, config_name: str) -> tuple[str, str, str]:
    for owner_pattern, config_pattern, intent_id, status, note in RULES:
        if fnmatch(owner, owner_pattern) and fnmatch(config_name, config_pattern):
            return intent_id, status, note

    intent_id = DEFAULT_INTENT_BY_OWNER[owner]
    if owner == "drupal_cms_starter":
        return (
            intent_id,
            "starter_aggregate_or_core_default",
            "Starter ships aggregate/core/contrib default config; no separate seed intent recommended without human review.",
        )

    return (
        intent_id,
        "recipe_level_context",
        "Covered by recipe-level intent fallback; review before seeding if this exact config matters.",
    )


def add_row(rows: list[dict[str, str]], catalog: dict[str, str], source_type: str, owner: str, config_name: str, path: Path | None) -> None:
    intent_id, status, note = match_intent(owner, config_name)
    rows.append({
        "source_type": source_type,
        "source_owner": owner,
        "config_name": config_name,
        "relative_path": "" if path is None else str(path.relative_to(DRUPAL_CMS_ROOT)),
        "v0_attachable": infer_v0_attachable(config_name),
        "coverage_status": status,
        "intent_id": intent_id,
        "intent_value": catalog[intent_id],
        "coverage_note": note,
    })


def build_rows() -> list[dict[str, str]]:
    catalog = load_catalog()
    rows: list[dict[str, str]] = []

    for recipe_dir in sorted((DRUPAL_CMS_ROOT / "recipes").glob("drupal_cms_*")):
        owner = recipe_dir.name
        for path in sorted((recipe_dir / "config").glob("**/*.yml")):
            add_row(rows, catalog, "recipe_config_file", owner, config_name_from_file(path), path)

        recipe_yml = recipe_dir / "recipe.yml"
        if recipe_yml.exists():
            for target in action_targets(recipe_yml):
                add_row(rows, catalog, "recipe_action_target", owner, target, recipe_yml)

    for path in sorted((DRUPAL_CMS_ROOT / "drupal_cms_installer" / "config" / "install").glob("*.yml")):
        add_row(rows, catalog, "drupal_cms_profile_config_file", "drupal_cms_installer", config_name_from_file(path), path)

    return rows


def main() -> None:
    rows = build_rows()
    fieldnames = [
        "source_type",
        "source_owner",
        "config_name",
        "relative_path",
        "v0_attachable",
        "coverage_status",
        "intent_id",
        "intent_value",
        "coverage_note",
    ]
    with COVERAGE_PATH.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, quoting=csv.QUOTE_ALL)
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} rows to {COVERAGE_PATH}")


if __name__ == "__main__":
    main()
