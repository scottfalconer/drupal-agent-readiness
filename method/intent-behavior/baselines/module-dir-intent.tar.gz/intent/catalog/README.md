# Drupal CMS Recipe Intent Catalog

This folder catalogs candidate `third_party_settings.intent.value` strings for Drupal CMS recipe configuration and tracks coverage for every config object shipped by the Drupal CMS recipes plus the Drupal CMS installer profile.

The purpose is not to reverse-engineer every product decision perfectly. The purpose is to separate intent that is well supported by evidence from intent that is merely inferred, so the first seed set stays honest.

## Method

For each Drupal CMS recipe, inspect:

- the recipe README and `recipe.yml`;
- shipped config files under `config/`;
- inline comments in recipe/config YAML;
- local git history for issue-linked commits;
- specific Drupal.org issues when the recipe or history gives an issue number.

Rows use this confidence scale:

- `0.90-1.00`: explicit human context from an issue/comment or very direct recipe comment, plus matching shipped config.
- `0.70-0.89`: recipe README/config strongly states the purpose, but no deeper human rationale was found.
- `0.40-0.69`: inferred from config/module choices and labels.
- `0.00-0.39`: unclear or not enough evidence to seed without human review.

`v0_attachable` matters because the lightweight `intent` module only stores one value on config entities that support third-party settings. Some important recipe decisions currently live in simple config actions. Those are cataloged as gaps, not as immediately attachable seed rows.

## Files

- `drupal-cms-recipe-intents.csv`: grouped intent catalog with stable `intent_id` values, evidence, source notes, and confidence scores.
- `drupal-cms-config-coverage.csv`: one row per shipped config file and one row per top-level recipe action target.
- `build_drupal_cms_config_coverage.py`: reproducible generator for the coverage manifest.

The coverage manifest includes:

- `709` config files under `recipes/drupal_cms_*/config/**/*.yml`;
- `1` config file under `drupal_cms_installer/config/install/*.yml`;
- `134` top-level recipe action targets from `recipe.yml` files.

`starter_aggregate_or_core_default` means the config is present in the `drupal_cms_starter` aggregate export but is treated as Starter/core/default site scaffolding rather than a separate seed intent. Recognizable copied config, such as media image styles, SEO fields, search config, privacy apps, and content model config, is mapped to the more specific component intent instead.

## First-Principles Rule

Only seed intent when it would help a human or agent consider the consequence of a change before making it. Do not use intent to enforce policy, freeze configuration, list safe adaptations, or document generic module behavior.
