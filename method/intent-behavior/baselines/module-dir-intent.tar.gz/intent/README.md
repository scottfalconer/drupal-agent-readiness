# Intent

Intent attaches one plain-language note to Drupal config entities so agents and humans can understand why a configuration choice exists before changing it.

The module stores intent in the config entity's existing third-party settings:

```yaml
third_party_settings:
  intent:
    value: 'Keep the SEO title and description fields visible because editors own per-page search snippets.'
```

Intent is not an enforcement system. It is context. A person or agent can still change the config, but should first read the intent and decide whether the change preserves it, changes it, or makes it obsolete.

## Commands

Intent uses Drupal core's `dr` command API in Drupal 11.4+.

```bash
./vendor/bin/dr intent:list --format=json
./vendor/bin/dr intent:get node.type.article --format=json
./vendor/bin/dr intent:set node.type.article --value='Editors need per-article SEO controls.' --format=json
./vendor/bin/dr intent:delete node.type.article --format=json
```

All commands currently return JSON only.

## Agent Protocol

When changing Drupal configuration:

1. Read relevant intent before editing config.
2. Consider the intent as context, not as a lock.
3. If the change makes the intent false or misleading, update or delete the intent in the same change.
4. If it is unclear whether the intent still applies, recommend asking a human.

## Scope

This first version is intentionally narrow:

- Stores one string at `third_party_settings.intent.value`.
- Supports config entities that already have third-party settings.
- Provides list/get/set/delete commands.
- Uses direct mutation; version control records history.
- Does not define policy, safe-change lists, verification commands, status, authorship, or a change log.

The schema file covers Drupal core config-entity schema families. Contrib config entity types can add matching third-party schema entries such as:

```yaml
example.type.*.third_party.intent:
  type: intent.third_party
```
