<?php

// phpcs:ignoreFile
// Dependency-free executable smoke test, not a Drupal class file.

declare(strict_types=1);

use Drupal\Core\Config\Entity\ThirdPartySettingsInterface;
use Drupal\intent\IntentStorage;

require_once __DIR__ . '/../../../cms-clean-install/vendor/autoload.php';
require_once __DIR__ . '/../../src/IntentStorage.php';

final class FakeThirdPartySettings implements ThirdPartySettingsInterface {

  public array $settings = [];

  public function setThirdPartySetting($module, $key, $value) {
    $this->settings[$module][$key] = $value;
    return $this;
  }

  public function getThirdPartySetting($module, $key, $default = NULL) {
    return $this->settings[$module][$key] ?? $default;
  }

  public function getThirdPartySettings($module) {
    return $this->settings[$module] ?? [];
  }

  public function unsetThirdPartySetting($module, $key) {
    $value = $this->settings[$module][$key] ?? NULL;
    unset($this->settings[$module][$key]);
    if (isset($this->settings[$module]) && $this->settings[$module] === []) {
      unset($this->settings[$module]);
    }
    return $value;
  }

  public function getThirdPartyProviders() {
    return array_keys($this->settings);
  }

}

function assert_same(mixed $expected, mixed $actual, string $message): void {
  if ($expected !== $actual) {
    fwrite(STDERR, $message . PHP_EOL);
    fwrite(STDERR, 'Expected: ' . var_export($expected, TRUE) . PHP_EOL);
    fwrite(STDERR, 'Actual:   ' . var_export($actual, TRUE) . PHP_EOL);
    exit(1);
  }
}

function assert_throws(callable $callback, string $message): void {
  try {
    $callback();
  }
  catch (InvalidArgumentException) {
    return;
  }
  fwrite(STDERR, $message . PHP_EOL);
  exit(1);
}

$storage = new IntentStorage();
$entity = new FakeThirdPartySettings();

assert_same(NULL, $storage->get($entity), 'Missing intent should read as NULL.');

$storage->set($entity, '  Editors can maintain SEO metadata separately.  ');
assert_same(
  ['intent' => ['value' => 'Editors can maintain SEO metadata separately.']],
  $entity->settings,
  'Intent should be stored only at third_party_settings.intent.value.',
);
assert_same(
  'Editors can maintain SEO metadata separately.',
  $storage->get($entity),
  'Intent should be trimmed when stored and read.',
);

$entity->settings['intent']['value'] = ['not' => 'a string'];
assert_same(NULL, $storage->get($entity), 'Non-string intent values should not be reported as valid intent.');

assert_throws(
  static fn () => $storage->set($entity, '   '),
  'Empty intent values should be rejected.',
);

$storage->set($entity, 'Updated intent.');
$storage->delete($entity);
assert_same([], $entity->settings, 'Deleting intent should remove the intent provider when no values remain.');

echo "intent_storage_test passed\n";
