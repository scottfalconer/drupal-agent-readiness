<?php

declare(strict_types=1);

namespace Drupal\intent;

use Drupal\Core\Config\Entity\ThirdPartySettingsInterface;

/**
 * Stores one plain-language intent string on third-party-settings entities.
 */
final class IntentStorage {

  /**
   * The third-party-settings provider name.
   */
  public const PROVIDER = 'intent';

  /**
   * The third-party-settings key used for the intent string.
   */
  public const KEY = 'value';

  /**
   * Gets the intent string from an entity, if present and valid.
   */
  public function get(ThirdPartySettingsInterface $entity): ?string {
    $value = $entity->getThirdPartySetting(self::PROVIDER, self::KEY);
    if (!is_string($value)) {
      return NULL;
    }
    $value = trim($value);
    return $value === '' ? NULL : $value;
  }

  /**
   * Sets the intent string on an entity.
   */
  public function set(ThirdPartySettingsInterface $entity, string $value): void {
    $value = trim($value);
    if ($value === '') {
      throw new \InvalidArgumentException('Intent value must not be empty.');
    }
    $entity->setThirdPartySetting(self::PROVIDER, self::KEY, $value);
  }

  /**
   * Deletes the intent string from an entity.
   */
  public function delete(ThirdPartySettingsInterface $entity): void {
    $entity->unsetThirdPartySetting(self::PROVIDER, self::KEY);
  }

}
