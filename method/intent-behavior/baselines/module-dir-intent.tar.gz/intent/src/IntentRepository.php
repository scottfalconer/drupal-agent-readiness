<?php

declare(strict_types=1);

namespace Drupal\intent;

use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Config\Entity\ConfigEntityTypeInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Finds config entities and reads/writes their attached intent.
 */
final class IntentRepository {

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly IntentStorage $intentStorage,
  ) {}

  /**
   * Lists config entities that currently have intent.
   *
   * @return array{intent_count:int,items:list<array{config:string,intent:string}>}
   *   A JSON-friendly result.
   */
  public function list(): array {
    $items = [];
    foreach ($this->getConfigEntityTypeDefinitions() as $entity_type_id => $definition) {
      $storage = $this->entityTypeManager->getStorage($entity_type_id);
      foreach ($storage->loadMultiple() as $entity) {
        if (!$entity instanceof ConfigEntityInterface) {
          continue;
        }
        $intent = $this->intentStorage->get($entity);
        if ($intent === NULL) {
          continue;
        }
        $items[] = [
          'config' => $this->getConfigName($definition, $entity),
          'intent' => $intent,
        ];
      }
    }

    usort($items, static fn (array $a, array $b): int => $a['config'] <=> $b['config']);

    return [
      'intent_count' => count($items),
      'items' => $items,
    ];
  }

  /**
   * Gets intent for one config entity.
   *
   * @return array{config:string,intent:?string}
   *   A JSON-friendly result.
   */
  public function get(string $config_name): array {
    $entity = $this->loadEntity($config_name);

    return [
      'config' => $config_name,
      'intent' => $this->intentStorage->get($entity),
    ];
  }

  /**
   * Sets intent for one config entity.
   *
   * @return array{config:string,intent:string}
   *   A JSON-friendly result.
   */
  public function set(string $config_name, string $value): array {
    $entity = $this->loadEntity($config_name);
    $this->intentStorage->set($entity, $value);
    $entity->save();

    return [
      'config' => $config_name,
      'intent' => $this->intentStorage->get($entity),
    ];
  }

  /**
   * Deletes intent from one config entity.
   *
   * @return array{config:string,deleted:bool}
   *   A JSON-friendly result.
   */
  public function delete(string $config_name): array {
    $entity = $this->loadEntity($config_name);
    $deleted = $this->intentStorage->get($entity) !== NULL;
    if ($deleted) {
      $this->intentStorage->delete($entity);
      $entity->save();
    }

    return [
      'config' => $config_name,
      'deleted' => $deleted,
    ];
  }

  /**
   * Loads a config entity by full config object name.
   */
  private function loadEntity(string $config_name): ConfigEntityInterface {
    foreach ($this->getConfigEntityTypeDefinitions() as $entity_type_id => $definition) {
      $prefix = $definition->getConfigPrefix() . '.';
      if (!str_starts_with($config_name, $prefix)) {
        continue;
      }

      $id = substr($config_name, strlen($prefix));
      $entity = $this->entityTypeManager->getStorage($entity_type_id)->load($id);
      if ($entity instanceof ConfigEntityInterface) {
        return $entity;
      }
    }

    throw new \InvalidArgumentException(sprintf('No config entity found for "%s". Intent v0 only supports config entities with third-party settings.', $config_name));
  }

  /**
   * Gets config entity type definitions, longest prefix first.
   *
   * @return array<string,\Drupal\Core\Config\Entity\ConfigEntityTypeInterface>
   *   Config entity type definitions keyed by entity type ID.
   */
  private function getConfigEntityTypeDefinitions(): array {
    $definitions = array_filter(
      $this->entityTypeManager->getDefinitions(),
      static fn ($definition): bool => $definition instanceof ConfigEntityTypeInterface,
    );

    uasort(
      $definitions,
      static fn (ConfigEntityTypeInterface $a, ConfigEntityTypeInterface $b): int => strlen($b->getConfigPrefix()) <=> strlen($a->getConfigPrefix()),
    );

    return $definitions;
  }

  /**
   * Gets the full config object name for a config entity.
   */
  private function getConfigName(ConfigEntityTypeInterface $definition, ConfigEntityInterface $entity): string {
    return $definition->getConfigPrefix() . '.' . $entity->id();
  }

}
