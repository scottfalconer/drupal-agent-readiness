<?php

declare(strict_types=1);

namespace Drupal\intent\Command;

use Drupal\intent\IntentRepository;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Lists config entities with attached intent.
 */
#[AsCommand(
  name: 'intent:list',
  description: 'Lists config entities with attached intent.',
)]
final class IntentListCommand extends Command {

  use JsonCommandTrait;

  public function __construct(
    #[Autowire(service: 'intent.repository')]
    private readonly IntentRepository $repository,
  ) {
    parent::__construct();
  }

  /**
   * {@inheritdoc}
   */
  protected function configure(): void {
    $this->addFormatOption();
  }

  /**
   * {@inheritdoc}
   */
  protected function execute(InputInterface $input, OutputInterface $output): int {
    if (!$this->isJsonFormat($input)) {
      $this->writeJson($output, ['error' => 'Only --format=json is supported.']);
      return Command::INVALID;
    }

    $this->writeJson($output, $this->repository->list());
    return Command::SUCCESS;
  }

}
