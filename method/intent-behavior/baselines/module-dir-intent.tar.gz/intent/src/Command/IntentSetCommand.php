<?php

declare(strict_types=1);

namespace Drupal\intent\Command;

use Drupal\intent\IntentRepository;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Sets attached intent for one config entity.
 */
#[AsCommand(
  name: 'intent:set',
  description: 'Sets attached intent for one config entity.',
)]
final class IntentSetCommand extends Command {

  use JsonCommandTrait;

  public function __construct(
    #[Autowire(service: 'intent.repository')]
    private readonly IntentRepository $repository,
  ) {
    parent::__construct();
  }

  /**
   * {@inheritdoc}
   */
  protected function configure(): void {
    $this->addArgument('config_name', InputArgument::REQUIRED, 'Full config entity object name.');
    $this->addOption('value', NULL, InputOption::VALUE_REQUIRED, 'Plain-language intent value.');
    $this->addFormatOption();
  }

  /**
   * {@inheritdoc}
   */
  protected function execute(InputInterface $input, OutputInterface $output): int {
    if (!$this->isJsonFormat($input)) {
      $this->writeJson($output, ['error' => 'Only --format=json is supported.']);
      return Command::INVALID;
    }

    $value = $input->getOption('value');
    if (!is_string($value) || trim($value) === '') {
      $this->writeJson($output, ['error' => 'The --value option is required and must not be empty.']);
      return Command::INVALID;
    }

    try {
      $this->writeJson($output, $this->repository->set((string) $input->getArgument('config_name'), $value));
      return Command::SUCCESS;
    }
    catch (\InvalidArgumentException $e) {
      $this->writeJson($output, ['error' => $e->getMessage()]);
      return Command::FAILURE;
    }
  }

}
