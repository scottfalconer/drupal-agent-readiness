<?php

declare(strict_types=1);

namespace Drupal\intent\Command;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Small JSON helper for intent commands.
 */
trait JsonCommandTrait {

  /**
   * Adds the only supported output-format option.
   */
  protected function addFormatOption(): void {
    $this->addOption('format', NULL, InputOption::VALUE_REQUIRED, 'Output format. Only json is supported.', 'json');
  }

  /**
   * Returns TRUE when JSON output was requested.
   */
  protected function isJsonFormat(InputInterface $input): bool {
    return $input->getOption('format') === 'json';
  }

  /**
   * Writes pretty JSON.
   */
  protected function writeJson(OutputInterface $output, array $data): void {
    $output->writeln(json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
  }

}
