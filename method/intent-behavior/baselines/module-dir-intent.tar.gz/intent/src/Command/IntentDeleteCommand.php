<?php

declare(strict_types=1);

namespace Drupal\intent\Command;

use Drupal\intent\IntentRepository;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Deletes attached intent for one config entity.
 */
#[AsCommand(
  name: 'intent:delete',
  description: 'Deletes attached intent for one config entity.',
)]
final class IntentDeleteCommand extends Command {

  use JsonCommandTrait;

  public function __construct(
    #[Autowire(service: 'intent.repository')]
    private readonly IntentRepository $repository,
  ) {
    parent::__construct();
  }

  /**
   * {@inheritdoc}
   */
  protected function configure(): void {
    $this->addArgument('config_name', InputArgument::REQUIRED, 'Full config entity object name.');
    $this->addFormatOption();
  }

  /**
   * {@inheritdoc}
   */
  protected function execute(InputInterface $input, OutputInterface $output): int {
    if (!$this->isJsonFormat($input)) {
      $this->writeJson($output, ['error' => 'Only --format=json is supported.']);
      return Command::INVALID;
    }

    try {
      $this->writeJson($output, $this->repository->delete((string) $input->getArgument('config_name')));
      return Command::SUCCESS;
    }
    catch (\InvalidArgumentException $e) {
      $this->writeJson($output, ['error' => $e->getMessage()]);
      return Command::FAILURE;
    }
  }

}
