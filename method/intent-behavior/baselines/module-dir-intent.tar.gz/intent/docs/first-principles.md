# First Principles

## Problem

Drupal recipes and templates can encode good configuration, but exported config often does not explain why those choices were made. Agents and humans can then simplify, rename, hide, or remove configuration without realizing which decisions were deliberate.

## Goal

Make the reason for a config decision durable and easy to query at the point where config changes happen.

## Minimal Model

The smallest useful model is one plain-language string:

```yaml
third_party_settings:
  intent:
    value: 'Why this config choice exists.'
```

This is enough to make an agent pause and consider the prior decision. It is also simple enough for recipe authors, site builders, and maintainers to write without learning a policy language.

## What Intent Is

Intent is context for judgment. It should explain the reason behind a configuration choice, especially when the reason is not obvious from the config values alone.

Good intent describes why a decision matters:

```text
Editors need per-page SEO title and description controls because marketing owns search snippets independently from page titles.
```

## What Intent Is Not

Intent is not a lock, rule engine, workflow, approval system, or audit log. It should not try to enumerate safe changes. A human or agent still has to decide whether the requested change is appropriate.

This version deliberately omits:

- Verification commands.
- Safe-adaptation lists.
- Change categories that require an intent update.
- Active, narrowed, retired, or superseded status.
- Changed-by or changed-because metadata.
- Amendment history.

Those can be handled by normal review, version control, and project process until there is evidence that the module itself must own them.

## Write And Change Rule

When config changes, read the relevant intent first. If the change preserves the reason, leave it. If the change changes the reason, update it. If the reason no longer applies, delete it. If this is unclear, recommend asking a human.

That is the whole contract.
